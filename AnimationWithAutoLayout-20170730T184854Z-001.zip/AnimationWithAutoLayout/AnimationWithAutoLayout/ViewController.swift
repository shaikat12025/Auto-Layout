//
//  ViewController.swift
//  AnimationWithAutoLayout
//
//  Created by Sium on 7/8/17.
//  Copyright © 2017 Sium. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    
    
    @IBOutlet weak var ViewBottomSpace: NSLayoutConstraint!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    
    
    @IBAction func ClickMeToAnimate(_ sender: Any) {
        
        //AnimationView()
        animate()
    }
    
    func AnimationView(){
        
        ViewBottomSpace.constant = 0
        
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseIn, animations: {
            //what you want to animate
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    

    func animate(){
        ViewBottomSpace.constant = 0
        UIView.animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.6, options: .curveEaseOut, animations: {self.view.layoutIfNeeded()}, completion: nil)
    }

}

